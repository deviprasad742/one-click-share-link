DOMAIN_URL = "https://one-click-share-link.herokuapp.com/";
POLL_INTERVAL = 1000 * 60;